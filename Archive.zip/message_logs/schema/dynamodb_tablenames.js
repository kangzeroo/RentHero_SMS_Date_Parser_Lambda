
exports.TOUR_HINTS = 'Tour_Hints_Parsed'
exports.COMMUNICATIONS_HISTORY = 'Communication_Logs'
